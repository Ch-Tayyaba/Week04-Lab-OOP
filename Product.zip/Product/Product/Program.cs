﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Product
{
    class Program
    {
        public class customer
        {
            public string customername;
            public string customeraddress;
            public string customercontact;
            public List<product> product = new List<product>();

            public customer()
            {

            }
            public customer(string name, string add, string contact)
            {
                this.customername = name;
                this.customeraddress = add;
                this.customercontact = contact;
            }
            public customer addinfo()
            {
                Console.WriteLine("Enter your name");
                string name = Console.ReadLine();
                Console.WriteLine("Enter your address");
                string address = Console.ReadLine();
                Console.WriteLine("Enter your contact");
                string contact = Console.ReadLine();
                Console.WriteLine("Available Products in the shop");
                customer c = new customer(name, address, contact);
                return c;
            }
            public void availableProducts()
            {
                for (int idx = 0; idx < products.Count; idx++)
                {
                    Console.WriteLine(products[idx].pname);
                }
            }
            public void addProduct(List<product> products)
            {
                Console.Write("Enter How many products you want to buy: ");
                int c = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Products: ");
                for(int idx = 0; idx < c; idx++)
                {
                    Console.Write(idx + 1 + ".  ");
                    string name = Console.ReadLine();
                    for(int i = 0; i < products.Count; i++)
                    {
                        if(name == products[i].pname)
                        {
                            product p = products[i];
                            product.Add(p);
                        }
                    }
                }
            }
            public void viewallproducts()
            {
                Console.WriteLine("The customer has following products");
                for (int idx = 0; idx < product.Count; idx++)
                {
                    Console.WriteLine("Name of product: " + product[idx].pname + " Category of Product: " + product[idx].pcategory + " Price of Product:" + product[idx].pprice);
                }
            }
            public void calculateTax()
            {
                float tax = 0;
                Console.WriteLine("Tax on every product is 5%.");
                for (int idx = 0; idx < product.Count; idx++)
                {
                    float tax01 = (product[idx].pprice * 5) / 100.0F;
                    tax = tax + tax01;
                }
                Console.Write("The Tax of your Products is: " + tax + "%");

            }
        }

        public class product
        {
            public string pname;
            public string pcategory;
            public int pprice;
            public product()
            {

            }
            public product(string pname, string pcategory, int pprice)
            {
                this.pname = pname;
                this.pcategory = pcategory;
                this.pprice = pprice;
            }

            public product addproduct()
            {
                Console.WriteLine("Enter the name of the product");
                string pname = Console.ReadLine();
                Console.WriteLine("Enter the category of the product");
                string pcategory = Console.ReadLine();
                Console.WriteLine("Enter the product price");
                int pprice = int.Parse(Console.ReadLine());

                product p = new product(pname, pcategory, pprice);
                return p;
            }
            public void viewallproducts(List<product> products)
            {
                Console.WriteLine("The store has following products");
                for (int idx = 0; idx < products.Count; idx++)
                {
                    Console.WriteLine("Name of product: " + products[idx].pname + " Category of Product: " + products[idx].pcategory + " Price of Product:" + products[idx].pprice);
                }
            }
            
        }
        static List<product> products = new List<product>();
        static void Main(string[] args)
        {
            int option;

            product p = new product();
            customer c = new customer();

            do
            {
                Console.Clear();
                option = menu();
                Console.Clear();
                if (option == 1)
                {
                    p = p.addproduct();
                    products.Add(p);
                    Console.ReadKey();

                }
                else if (option == 2)
                {
                    p.viewallproducts(products);
                    Console.ReadKey();
                }
                else if (option == 3)
                {
                    c.addinfo();
                    c.availableProducts();
                    c.addProduct(products);
                    Console.ReadKey();
                }
                else if (option == 4)
                {
                    c.viewallproducts();
                    Console.ReadKey();
                }
                else if (option == 5)
                {
                    c.calculateTax();
                    Console.ReadKey();
                }
            }
            while (option < 6);
            Console.Read();

        }

        static int menu()
        {
            int option;
            Console.WriteLine("1.Add a product");
            Console.WriteLine("2.View all the products");
            Console.WriteLine("3.Buy/add product to cart");
            Console.WriteLine("4.Get all products");
            Console.WriteLine("5.Calculate Tax on Products");
            Console.WriteLine("6.Exit");
            option = int.Parse(Console.ReadLine());
            return option;
        }
    }
}
