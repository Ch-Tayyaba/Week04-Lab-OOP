﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UAMS
{
    class Program
    {
        static List<Student> studentList = new List<Student>();
        static List<Student> sortedStudentList = new List<Student>();
        static List<Degree_Program> programList = new List<Degree_Program>();
        static void Main(string[] args)
        {
            int option;
            do
            {
                option = Menu();
                Console.Clear();
                if (option == 1)
                {
                    if (programList.Count > 0)
                    {
                        Student s = takeInputForStudent();
                        addIntoStudentList(s);
                    }
                }
                else if (option == 2)
                {
                    Degree_Program d = takeInputForDegree();
                    addIntoDegreeList(d);
                }
                else if (option == 3)
                {
                    sortStudentsByMerit();
                    giveAdmission();
                    printStudents();
                }
                else if (option == 4)
                {
                    viewRegisteredStudents();
                    
                }
                else if (option == 5)
                {
                    string degName;
                    Console.Write("Enter Degree Name: ");
                    degName = Console.ReadLine();
                    viewStudentInDegree(degName);
                }
                else if (option == 6)
                {
                    Console.Write("Enter the Student Name: ");
                    string name = Console.ReadLine();
                    Student s = StudentPresent(name);
                    if (s != null)
                    {
                        s.viewSubjects(s);
                        registerSubjects(s);
                    }
                }
                else if (option == 7)
                {
                    calculateFee();
                }
                Console.WriteLine("Press any key to continue...");
                Console.ReadKey();
                Console.Clear();
            }
            while (option != 8);
            Console.ReadKey();
        }
        static int Menu()
        {
            Console.WriteLine("1. Add Student.");
            Console.WriteLine("2. Add Degree Program.");
            Console.WriteLine("3. Generate Merit.");
            Console.WriteLine("4. View Registered Students.");
            Console.WriteLine("5. View Students of Specific Program.");
            Console.WriteLine("6. Register Subjects for Specific Student.");
            Console.WriteLine("7. Calculate Fees for all Registered Students.");
            Console.WriteLine("8. Exit.");
            Console.Write("Enter option: ");
            int option = int.Parse(Console.ReadLine());
            return option;
        }
        static Student takeInputForStudent()
        {
            Console.Write("Enter your name: ");
            string name = Console.ReadLine();
            Console.Write("Enter your age: ");
            int age = int.Parse(Console.ReadLine());
            Console.Write("Enter your fsc marks: ");
            double fscMarks = double.Parse(Console.ReadLine());
            Console.Write("Enter your ecat marks: ");
            double ecatMarks = double.Parse(Console.ReadLine());
            Console.WriteLine("Available Degree Programs ");  
            for(int idx = 0; idx < programList.Count; idx ++)
            {
                 Console.WriteLine(programList[idx].degreeName);
            }
            Console.Write("Enter How many preferences to Enter:");
            int p = int.Parse(Console.ReadLine());
            List<Degree_Program> preferences = new List<Degree_Program>();
            for (int idx = 0; idx < p; idx++ )
            {
                Degree_Program obj = new Degree_Program();
                string degName = Console.ReadLine();
                obj.degreeName = degName;
                preferences.Add(obj);

            }
            Student s = new Student(name, age, fscMarks, ecatMarks, preferences);
            return s;
        }
        static void addIntoStudentList(Student s)
        {
            studentList.Add(s);
        }
        static Degree_Program takeInputForDegree()
        {
            Console.Write("Enter the degree Name: ");
            string name = Console.ReadLine();
            Console.Write("Enter the degree duration: ");
            int duration = int.Parse(Console.ReadLine());
            Console.Write("Enter the seats in this degree program: ");
            int seats = int.Parse(Console.ReadLine());
            Console.Write("Enter How many Subjects To Enter: ");
            int s = int.Parse(Console.ReadLine());
            List<Subject> subjects = new List<Subject>();
            for(int idx = 0; idx < s; idx++)
            {
                Console.Write("Enter the Subject Code: ");
                string code = Console.ReadLine();
                Console.Write("Enter the Subject Type: ");
                string type = Console.ReadLine();
                Console.Write("Enter the Credit Hours: ");
                int cHours = int.Parse(Console.ReadLine());
                Console.Write("Enter the Subject Fee: ");
                int fee = int.Parse(Console.ReadLine());
                Subject obj = new Subject(code, type, cHours, fee);
                subjects.Add(obj);
            }
            Degree_Program d = new Degree_Program(name, duration, seats, subjects);
            return d;
        }
        static void addIntoDegreeList(Degree_Program d)
        {
            programList.Add(d);
        }
       
        static int largest(double cLarge)
        {
            int index = 0;
            double large = 0.0F;
            for(int idx = 0; idx < studentList.Count; idx++)
            {
                if(large < studentList[idx].merit && cLarge > large)
                {
                    large = studentList[idx].merit;
                    index = idx;
                }
            }
            return index;
        }
        static void sortStudentsByMerit()
        {
            foreach(Student s in studentList)
            {
                s.calculateMerit();
            }
            sortedStudentList = studentList.OrderByDescending(o => o.merit).ToList();
        }
        static void giveAdmission()
        {
            for (int idx = 0; idx < sortedStudentList.Count; idx++)
            {
                foreach (Degree_Program d in studentList[idx].preferences)
                {
                    if (d.seats > 0 && sortedStudentList[idx].regDegree == null)
                    {
                        sortedStudentList[idx].regDegree = d;
                        d.seats--;
                        break;
                    }
                }
            }
        }
        static void printStudents()
        {
            for (int idx = 0; idx < studentList.Count; idx++)
            {
                if (studentList[idx].regDegree != null)
                {
                    Console.WriteLine(studentList[idx].name + "got Admission in " + studentList[idx].regDegree.degreeName);
                }
                if (studentList[idx].regDegree == null)
                {
                    Console.WriteLine(studentList[idx].name + "did not got Admission");
                }
            }
        }
        static void viewRegisteredStudents()
        {
            Console.WriteLine("Name\t\tFSC\t\tEcat\t\tAge");
            for (int idx = 0; idx < studentList.Count; idx++)
            {
                if (studentList[idx].regDegree != null)
                {
                    Console.WriteLine(studentList[idx].name + "\t\t" + studentList[idx].fscMarks + "\t\t" + studentList[idx].ecatMarks + "\t\t" + studentList[idx].age);
                }
            }
        }
        static void viewStudentInDegree(string degName)
        {
            Console.WriteLine("Name\t\tFSC\t\tEcat\t\tAge");
            for (int idx = 0; idx < studentList.Count; idx++)
            {
                if(degName == studentList[idx].regDegree.degreeName)
                {
                    Console.WriteLine(studentList[idx].name + "\t\t" + studentList[idx].fscMarks + "\t\t" + studentList[idx].ecatMarks + "\t\t" + studentList[idx].age);
                }
            }
        }
        static Student StudentPresent(string name)
        {
            for (int idx = 0; idx < studentList.Count; idx++)
            {
                if (name == studentList[idx].name)
                {
                    return studentList[idx];
                }
            }
            return null;
        }
        static void calculateFee()
        {
            for (int idx = 0; idx < studentList.Count; idx++)
            {
                studentList[idx].calculateFee();
                Console.WriteLine(studentList[idx].name + "\t\t" + studentList[idx].fscMarks + "\t\t" + studentList[idx].ecatMarks + "\t\t" + studentList[idx].age);
            }
        }
        static void registerSubjects(Student s)
        {
            Console.WriteLine("Enter How many subjects you want to register");
            int count = int.Parse(Console.ReadLine());
            for(int x = 0; x < count; x++)
            {
                Console.WriteLine("Enter the Subject Code");
                string code = Console.ReadLine();
                bool flag = false;
                foreach(Subject sub in s.regDegree.subjects)
                {
                    if(code == sub.code && !(s.regSubject.Contains(sub)))
                    {
                        s.regStudentSubject(sub);
                        flag = true;
                        break;
                    }
                    if (flag == false)
                    {
                        Console.WriteLine("Enter Valid Course");
                        x--;
                    }
                }
            }
        }
    }
}
