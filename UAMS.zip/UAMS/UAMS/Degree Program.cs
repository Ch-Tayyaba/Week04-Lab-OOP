﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UAMS
{
    class Degree_Program
    { 
        public string degreeName;
        public float degreeDuration;
        public int seats;
        public List<Subject> subjects;

        public Degree_Program()
        {

        }
        public Degree_Program(string degreeName, float degreeDuration, int seats, List<Subject> subjects)
        {
            this.degreeName = degreeName;
            this.degreeDuration = degreeDuration;
            this.seats = seats;
            this.subjects = subjects;
        }
        public int calculateCreditHours()
        {
            int hours = 0;
            for (int idx = 0; idx < subjects.Count; idx++)
            {
                hours = hours + subjects[idx].creditHours;
            }
            return hours;
        }
        public bool isSubjectExists(Subject sub)
        {
            for (int idx = 0; idx < subjects.Count; idx++)
            {
                if (sub == subjects[idx])
                {
                    return true;
                }
            }
            return false;
        }
        public void AddSubject(Subject s)
        {
            int creditHours = calculateCreditHours();
            if (creditHours + s.creditHours <= 20)
            {
                subjects.Add(s);
            }
            else
            {
                Console.WriteLine("20 credit hour limit exceeded");
            }
        }
    }
    
}


